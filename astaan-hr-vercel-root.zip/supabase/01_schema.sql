-- =====================================================================
-- Astaan HR Portal · Supabase schema
-- Run this whole file once in Supabase → SQL Editor → New query → Run.
-- =====================================================================

-- Every collection is a table of (id, data jsonb). The app reads and writes
-- the JSON documents; the policies below decide who may do what.
create table if not exists public.employees (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());
create table if not exists public.leaves    (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());
create table if not exists public.advances  (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());
create table if not exists public.settings  (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());
-- roles: one row per login (id = auth user id). data = {role, empId}
create table if not exists public.roles     (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());
-- users: profile of each login (name, email, phone, photo, lastSeen …)
create table if not exists public.users     (id text primary key, data jsonb not null default '{}', updated_at timestamptz not null default now());

-- ---------- helper functions (run with owner rights so policies can call them)
create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select data->>'role' from public.roles where id = auth.uid()::text
$$;
create or replace function public.my_emp() returns text
language sql stable security definer set search_path = public as $$
  select data->>'empId' from public.roles where id = auth.uid()::text
$$;
-- department each director role manages
create or replace function public.my_dept() returns text
language sql stable security definer set search_path = public as $$
  select case public.my_role()
    when 'HR' then 'HR & Logistics'  when 'CC' then 'Customer Care' when 'SALES' then 'Sales'
    when 'TOWER' then 'Broadcast Tower Dept' when 'FIN' then 'Finance' when 'PROD' then 'Production'
    when 'DUB' then 'Films Dubbing' when 'MKT' then 'Marketing' when 'TECH' then 'Technician'
    when 'GM' then 'Management' else null end
$$;
-- department of an employee record (leaves imported without a department follow the employee)
create or replace function public.emp_dept(eid text) returns text
language sql stable security definer set search_path = public as $$
  select nullif(data->>'dept','') from public.employees where id = eid
$$;
create or replace function public.has_role() returns boolean
language sql stable security definer set search_path = public as $$ select public.my_role() is not null $$;
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$ select coalesce(public.my_role() in ('SA','HR'), false) $$;
create or replace function public.is_sa() returns boolean
language sql stable security definer set search_path = public as $$ select coalesce(public.my_role() = 'SA', false) $$;

-- ---------- keep updated_at fresh
create or replace function public.touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
do $$ declare t text; begin
  foreach t in array array['employees','leaves','advances','settings','roles','users'] loop
    execute format('drop trigger if exists touch_%1$s on public.%1$s', t);
    execute format('create trigger touch_%1$s before update on public.%1$s for each row execute function public.touch()', t);
  end loop; end $$;

-- ---------- new login → profile row; the very first login becomes Super Admin
create or replace function public.on_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.users(id, data) values (new.id::text, jsonb_build_object(
      'email', new.email,
      'name', coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
      'phone', coalesce(new.raw_user_meta_data->>'phone',''),
      'firstSeen', now()))
    on conflict (id) do nothing;
  if not exists (select 1 from public.roles) then
    insert into public.roles(id, data) values (new.id::text, '{"role":"SA"}');
  end if;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.on_new_user();

-- ---------- Row Level Security
alter table public.employees enable row level security;
alter table public.leaves    enable row level security;
alter table public.advances  enable row level security;
alter table public.settings  enable row level security;
alter table public.roles     enable row level security;
alter table public.users     enable row level security;

do $$ declare t text; p record; begin
  foreach t in array array['employees','leaves','advances','settings','roles','users'] loop
    for p in select policyname from pg_policies where schemaname='public' and tablename=t loop
      execute format('drop policy %I on public.%I', p.policyname, t);
    end loop;
  end loop; end $$;

-- settings: everyone with a role reads; only Super Admin writes
create policy settings_read  on public.settings for select using (public.has_role());
create policy settings_write on public.settings for all using (public.is_sa()) with check (public.is_sa());

-- roles: everyone with a role reads (needed to route approvals); HR / Super Admin write
create policy roles_read  on public.roles for select using (public.has_role() or id = auth.uid()::text);
create policy roles_write on public.roles for all using (public.is_admin()) with check (public.is_admin());

-- users (profiles): staff with a role read; you write your own row; HR / Super Admin write any
create policy users_read  on public.users for select using (public.has_role() or id = auth.uid()::text);
create policy users_own   on public.users for insert with check (id = auth.uid()::text or public.is_admin());
create policy users_upd   on public.users for update using (id = auth.uid()::text or public.is_admin());
create policy users_del   on public.users for delete using (public.is_sa());

-- employees: staff with a role read; HR / SA write all; a department manager writes
-- staff in their own department or staff with no department yet; HR / SA delete
create policy emp_read on public.employees for select using (public.has_role());
create policy emp_ins  on public.employees for insert with check (
  public.is_admin() or (public.my_dept() is not null and data->>'dept' = public.my_dept()));
create policy emp_upd  on public.employees for update using (
  public.is_admin() or (public.my_dept() is not null and coalesce(data->>'dept','') in ('', public.my_dept())))
  with check (public.is_admin() or (public.my_dept() is not null and data->>'dept' = public.my_dept()));
create policy emp_del  on public.employees for delete using (public.is_admin());

-- leaves: SA / HR / GM see all; a manager sees their department; everyone sees their own
create policy lv_read on public.leaves for select using (
  public.my_role() in ('SA','HR','GM')
  or (public.my_dept() is not null and coalesce(nullif(data->>'dept',''), public.emp_dept(data->>'empId')) = public.my_dept())
  or data->>'empId' = public.my_emp());
-- anyone with a role can submit; new requests must start pending unless HR / SA record them
create policy lv_ins on public.leaves for insert with check (
  public.has_role() and (public.is_admin() or data->>'status' in ('hr','gm')));
-- decisions: HR, GM and Super Admin
create policy lv_upd on public.leaves for update using (public.my_role() in ('SA','HR','GM'));
create policy lv_del on public.leaves for delete using (public.is_sa());

-- advances: SA / HR / GM / Finance see all; a manager sees their department; you see your own
create policy adv_read on public.advances for select using (
  public.my_role() in ('SA','HR','GM','FIN')
  or (public.my_dept() is not null and coalesce(nullif(data->>'dept',''), public.emp_dept(data->>'empId')) = public.my_dept())
  or data->>'empId' = public.my_emp());
create policy adv_ins on public.advances for insert with check (
  public.has_role() and (public.is_sa() or data->>'status' in ('dept','hr')));
create policy adv_upd on public.advances for update using (
  public.my_role() in ('SA','HR','GM','FIN')
  or (public.my_dept() is not null and coalesce(nullif(data->>'dept',''), public.emp_dept(data->>'empId')) = public.my_dept()));
create policy adv_del on public.advances for delete using (public.is_sa());

-- live updates in the app
do $$ declare t text; begin
  foreach t in array array['employees','leaves','advances','settings','roles','users'] loop
    begin execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null; end;
  end loop; end $$;
